package geektrust.family;

/**
 * @author Arnab Nandy
 */
public enum Gender {
    MALE,
    FEMALE
}
